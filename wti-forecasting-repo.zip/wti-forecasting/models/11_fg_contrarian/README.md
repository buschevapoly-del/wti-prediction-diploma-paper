# Model 11: Pure Fear & Greed Contrarian Signal

## Results
54.50% Post-2020 | 211 trades | 2020-2026

## Usage
```bash
python models/11_fg_contrarian/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
