# Model 08: Multi-Scale CNN 15 Channels + CoT GPT

## Results
47.78% Post-2020 | Sharpe -0.824 | 180 trades | 2020-2026

## Usage
```bash
python models/08_cnn_15ch_cot_gpt/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
