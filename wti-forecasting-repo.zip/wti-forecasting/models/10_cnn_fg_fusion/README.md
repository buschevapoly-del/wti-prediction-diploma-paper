# Model 10: CNN + Fear & Greed Fusion 74 folds

## Results
47.93% Post-2020 | Sharpe 0.232 | 603 trades | 2013-2026

## Usage
```bash
python models/10_cnn_fg_fusion/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
