# Model 06: Multi-Scale CNN 4 Channels (WTI+RSI+MACD+Vol)

## Results
53.04% Post-2020 | Sharpe 0.423 | 115 trades | 2020-2026

## Usage
```bash
python models/06_cnn_4ch/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
