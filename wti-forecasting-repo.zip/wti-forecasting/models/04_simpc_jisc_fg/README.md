# Model 04: SIMPC + JISC-Net + LightGBM: + Fear & Greed Index

## Results
50.58% Post-2020 | Sharpe 0.423 | 344 trades | 2014-2026

## Usage
```bash
python models/04_simpc_jisc_fg/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
