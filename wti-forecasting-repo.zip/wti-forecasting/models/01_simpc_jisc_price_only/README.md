# Model 01: SIMPC + JISC-Net + LightGBM: Price Only

## Results
55.56% Post-2020 | Sharpe 0.294 | 288 trades | 2000-2026

## Usage
```bash
python models/01_simpc_jisc_price_only/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
