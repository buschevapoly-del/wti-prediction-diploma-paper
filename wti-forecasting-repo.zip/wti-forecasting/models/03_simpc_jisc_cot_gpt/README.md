# Model 03: SIMPC + JISC-Net + LightGBM: + Chain-of-Thought GPT

## Results
55.76% Post-2020 | Sharpe 0.182 | 278 trades | 2000-2026

## Usage
```bash
python models/03_simpc_jisc_cot_gpt/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
