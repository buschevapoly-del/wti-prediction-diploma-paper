# Model 09: Multi-Scale CNN 15 Channels + Cross-Asset

## Results
46.73% Post-2020 | Sharpe -0.664 | 107 trades | 2000-2026

## Usage
```bash
python models/09_cnn_15ch_cross_asset/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
