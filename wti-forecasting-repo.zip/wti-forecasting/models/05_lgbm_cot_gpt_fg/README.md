# Model 05: LightGBM + CoT GPT + Fear & Greed  BEST MODEL

## Results
57.67% Post-2020 | Sharpe 0.532 | 215 trades | 2020-2026

## Usage
```bash
python models/05_lgbm_cot_gpt_fg/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
