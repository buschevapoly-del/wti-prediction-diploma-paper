# Model 07: Multi-Scale CNN 7 Channels + Fear & Greed

## Results
51.96% Post-2020 | Sharpe 0.026 | 102 trades | 2020-2026

## Usage
```bash
python models/07_cnn_7ch_fg/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
