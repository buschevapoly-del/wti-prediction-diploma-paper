# Model 02: SIMPC + JISC-Net + LightGBM: + GPT Direct Sentiment

## Results
56.76% Post-2020 | Sharpe 0.162 | 259 trades | 2000-2026

## Usage
```bash
python models/02_simpc_jisc_gpt_direct/model.py
```
Requires `data/econ_df_1.csv` — run `python data/data_loading.py` first.
