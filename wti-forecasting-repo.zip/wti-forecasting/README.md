# WTI Crude Oil Directional Forecasting

**Master's Thesis — Directional Forecasting of WTI Crude Oil Prices using Pattern Recognition, LLM Sentiment and Fear & Greed Index**

---

## Overview

This repository contains all models developed for the thesis. The goal is to predict whether WTI crude oil will be **higher or lower 5 trading days from now**, using price patterns, macroeconomic indicators, LLM-based news sentiment (CoT GPT), and the CNN Fear & Greed Index.

All models are trained on **FRED** + **Yahoo Finance** data covering 2000–2026.

---

## Results Summary

| # | Model | Training | Horizon | Trades | Post-2020 Acc. | Sharpe |
|---|-------|----------|---------|--------|----------------|--------|
| — | Random walk (baseline) | — | 5d | — | 50.00% | — |
| 1 | SIMPC+JISC+LGB: Price only | 2000–2026 | 5d | 288 | 55.56% | 0.294 |
| 2 | SIMPC+JISC+LGB: + GPT direct | 2000–2026 | 5d | 259 | 56.76% | 0.162 |
| 3 | SIMPC+JISC+LGB: + CoT GPT | 2000–2026 | 5d | 278 | 55.76% | 0.182 |
| 4 | SIMPC+JISC+LGB: + F&G | 2014–2026 | 5d | 344 | 50.58% | 0.423 |
| **5** | **LightGBM + CoT GPT + F&G** | **2020–2026** | **5d** | **215** | **57.67%** | **0.532** |
| 6 | CNN 4ch (WTI+RSI+MACD+Vol) | 2020–2026 | 5d | 115 | 53.04% | 0.423 |
| 7 | CNN 7ch + Fear & Greed | 2020–2026 | 5d | 102 | 51.96% | 0.026 |
| 8 | CNN 15ch + CoT GPT | 2020–2026 | 5d | 180 | 47.78% | −0.824 |
| 9 | CNN 15ch + cross-asset | 2000–2026 | 5d | 107 | 46.73% | −0.664 |
| 10 | CNN F&G fusion (74 folds) | 2013–2026 | 5d | 603 | 47.93% | 0.232 |
| 11 | Pure F&G contrarian signal | 2020–2026 | 5d | 211 | 54.50% | — |

**Model 5** achieves the best post-2020 accuracy (57.67%) and highest Sharpe ratio (0.532).

---

## Repository Structure

```
wti-directional-forecasting/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── data_loading.py              # FRED + Yahoo Finance pipeline
├── models/
│   ├── 01_simpc_jisc_price_only/    # SIMPC+JISC-Net, price features
│   ├── 02_simpc_jisc_gpt_direct/    # + GPT direct sentiment
│   ├── 03_simpc_jisc_cot_gpt/       # + Chain-of-Thought GPT
│   ├── 04_simpc_jisc_fg/            # + Fear & Greed Index
│   ├── 05_lgbm_cot_gpt_fg/          # ← BEST MODEL
│   ├── 06_cnn_4ch/                  # CNN 4 channels
│   ├── 07_cnn_7ch_fg/               # CNN 7ch + Fear & Greed
│   ├── 08_cnn_15ch_cot_gpt/         # CNN 15ch + CoT GPT
│   ├── 09_cnn_15ch_cross_asset/     # CNN 15ch + cross-asset
│   ├── 10_cnn_fg_fusion/            # CNN + F&G fusion (74 folds)
│   └── 11_fg_contrarian/            # Pure F&G contrarian signal
└── results/
    └── results_table.md
```

---

## Key Methodological Contributions

**1. Two-Track Feature Strategy** — Correlation analysis (WTI↔Brent = 0.993) led to using 4 decorrelated features for SIMPC clustering (WTI, Gold, Dollar/Euro, Copper) and a broader set for the LightGBM classifier.

**2. Causal Smoothing** — All smoothing uses a backward-looking Gaussian kernel (no future data). The standard bilateral Nadaraya-Watson smoother causes data leakage, inflating accuracy to ~99%.

**3. Walk-Forward Backtesting** — Expanding-window scheme simulates real trading. No single static split.

**4. LLM Sentiment (CoT GPT)** — Chain-of-Thought GPT reasoning before scoring each headline outperforms single-pass GPT scoring for geopolitical oil news.

**5. Fear & Greed Integration** — CNN F&G Index (alternative.me, free) provides market regime context. Model 5 shows the best Sharpe (0.532) by combining F&G + CoT GPT + LightGBM.

---

## Data Sources

| Source | What |
|--------|------|
| FRED API | WTI, Brent, CPI, PPI, FedFunds, EU PPI, DJ, NASDAQ |
| Yahoo Finance | Gold, Copper, S&P500, Bitcoin |
| alternative.me | CNN Fear & Greed Index (free, no key) |
| GDELT / Reuters RSS | Oil news headlines for sentiment |
| OpenAI API | GPT-4o-mini for CoT sentiment scoring |

---

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/wti-directional-forecasting
cd wti-directional-forecasting
pip install -r requirements.txt
python data/data_loading.py       # downloads and saves econ_df_1.csv
```

**Running the best model (Model 5):**
```bash
python models/05_lgbm_cot_gpt_fg/model.py
```

For CNN models (6–10): open in **Google Colab** with GPU enabled (T4 or better).

**API keys needed:**
- OpenAI key: required for models 2, 3, 5, 8
- No key needed for models 1, 4, 6, 7, 10, 11

---

## References

Kim et al. (2025) — *From Patterns to Predictions: A Shapelet-Based Framework for Directional Forecasting in Noisy Financial Markets*. CIKM '25.
https://doi.org/10.1145/3746252.3761250

Jiang, Kelly & Xiu (2023) — *Re-Imagining Price Trends*. Journal of Finance.
https://github.com/lich99/Stock_CNN

---

## License

MIT. Data sourced from public APIs subject to their respective terms.
