# Full Results Table

## Post-2020 Accuracy (Walk-Forward Backtest, Horizon = 5 days)

| # | Model | Training | Trades | Post-2020 Acc. | Sharpe | Notes |
|---|-------|----------|--------|----------------|--------|-------|
| — | Random walk | — | — | 50.00% | — | Baseline |
| 1 | SIMPC+JISC+LGB: Price only | 2000–2026 | 288 | 55.56% | 0.294 | |
| 2 | SIMPC+JISC+LGB: + GPT direct | 2000–2026 | 259 | 56.76% | 0.162 | |
| 3 | SIMPC+JISC+LGB: + CoT GPT | 2000–2026 | 278 | 55.76% | 0.182 | |
| 4 | SIMPC+JISC+LGB: + F&G | 2014–2026 | 344 | 50.58% | 0.423 | F&G from 2014 |
| **5** | **LightGBM + CoT GPT + F&G** | **2020–2026** | **215** | **57.67%** | **0.532** | **Best model** |
| 6 | CNN 4ch (WTI+RSI+MACD+Vol) | 2020–2026 | 115 | 53.04% | 0.423 | |
| 7 | CNN 7ch + Fear & Greed | 2020–2026 | 102 | 51.96% | 0.026 | |
| 8 | CNN 15ch + CoT GPT | 2020–2026 | 180 | 47.78% | −0.824 | |
| 9 | CNN 15ch + cross-asset | 2000–2026 | 107 | 46.73% | −0.664 | |
| 10 | CNN F&G fusion (74 folds) | 2013–2026 | 603 | 47.93% | 0.232 | |
| 11 | Pure F&G contrarian | 2020–2026 | 211 | 54.50% | — | No ML |

## Key Findings

1. **Model 5 (LightGBM + CoT GPT + F&G)** achieves the best accuracy and Sharpe ratio
2. **CoT GPT outperforms direct GPT** (56.76% vs 55.76%) when added to SIMPC+JISC
3. **CNN models underperform** on WTI compared to tree-based models (insufficient data for image-based approach)
4. **Fear & Greed alone** (Model 11, 54.50%) beats several complex models — useful contrarian baseline
5. **All models beat random walk** (50%) on post-2020 data, confirming learnable signal exists
