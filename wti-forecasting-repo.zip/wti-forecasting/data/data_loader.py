"""
data_loader.py
==============
Shared data pipeline for all WTI forecasting models.
Builds econ_df_1 from FRED + yfinance.

Run this first before any model notebook.
"""

import pandas as pd
import numpy as np
import pandas_datareader.data as web
import yfinance as yf
from datetime import datetime
import time
import warnings
warnings.filterwarnings('ignore')


# ===========================================================================
# FRED data (macro indicators)
# ===========================================================================

FRED_SERIES = {
    'DCOILWTICO':       'WTI',
    'DEXUSEU':          'Dollar/Euro',
    'DJIA':             'DJ',
    'NASDAQCOM':        'NASDAQ',
    'DCOILBRENTEU':     'Brent',
    'CPIENGSL':         'US_CPI_energy',
    'CPIAUCSL':         'US_CPI_total',
    'PPIACO':           'US_PPI_total',
    'FEDFUNDS':         'Fed_Funds_Effective',
    'PIEAEN01EZM661N':  'EU_PPI',
}

YFINANCE_SYMBOLS = {
    '^GSPC':    'S&P500',
    'HG=F':     'Copper',
    'GC=F':     'Gold',
    'NG=F':     'Natural_Gas',
    'BTC-USD':  'Bitcoin',
}


def get_fred_data(start=datetime(2000, 1, 1), end=None, retries=3):
    if end is None:
        end = datetime.now()

    fred_df = pd.DataFrame()
    for series_id, col_name in FRED_SERIES.items():
        print(f"  Downloading {series_id} → {col_name} ...")
        for attempt in range(retries):
            try:
                df = web.get_data_fred(series_id, start, end)
                df.columns = [col_name]
                fred_df = df if fred_df.empty else fred_df.join(df, how='outer')
                break
            except Exception as e:
                if attempt < retries - 1:
                    time.sleep(2)
                else:
                    print(f"  ✗ Failed: {e}")
    return fred_df


def get_yfinance_data(start=datetime(2000, 1, 1), end=None):
    if end is None:
        end = datetime.now()

    tickers = list(YFINANCE_SYMBOLS.keys())
    raw     = yf.download(tickers, start=start, end=end,
                          progress=False)['Close']
    raw.columns = [YFINANCE_SYMBOLS[t] for t in tickers
                   if t in raw.columns]
    raw.index = pd.to_datetime(raw.index)
    return raw


def build_econ_df(start=datetime(2000, 1, 1)):
    """
    Builds the full econ_df_1 dataframe used by all models.

    Returns
    -------
    econ_df_1 : pd.DataFrame
        Daily index, all NaNs forward-filled, columns:
        WTI, Dollar/Euro, DJ, NASDAQ, Brent, US_CPI_energy,
        US_CPI_total, US_PPI_total, Fed_Funds_Effective, EU_PPI,
        S&P500, Copper, Gold, Natural_Gas, Bitcoin
    """
    print("[1/3] Downloading FRED data ...")
    fred = get_fred_data(start=start)
    fred.index = pd.to_datetime(fred.index)

    print("\n[2/3] Downloading yfinance data ...")
    yf_data = get_yfinance_data(start=start)

    print("\n[3/3] Merging and cleaning ...")
    econ_df_1 = fred.join(yf_data, how='outer')

    # Complete daily index + forward-fill
    full_dates = pd.date_range(start=econ_df_1.index.min(),
                               end=econ_df_1.index.max(), freq='D')
    econ_df_1  = econ_df_1.reindex(full_dates).ffill().bfill()

    # Drop Dow_Jones duplicate (already have DJ from FRED)
    econ_df_1  = econ_df_1.drop(columns=['Dow_Jones'], errors='ignore')

    print(f"\n✅ econ_df_1 ready:")
    print(f"   Shape  : {econ_df_1.shape}")
    print(f"   Period : {econ_df_1.index.min().date()} "
          f"→ {econ_df_1.index.max().date()}")
    print(f"   NaNs   : {econ_df_1.isna().sum().sum()}")
    print(f"   Columns: {list(econ_df_1.columns)}")
    return econ_df_1


# ===========================================================================
# Shared utilities
# ===========================================================================

def make_robust_labels(price_series, horizon=5, threshold=0.003):
    """
    1  = UP   if 5-day return > +threshold
    0  = DOWN if 5-day return < -threshold
    -1 = NEUTRAL (skip — avoids training on noise)
    """
    ret = (price_series.shift(-horizon) - price_series) / \
          (price_series + 1e-8)
    return np.where(ret >  threshold,  1,
           np.where(ret < -threshold,  0, -1))


def causal_smooth(series, h=5):
    """
    Backward-looking Gaussian kernel smoothing.
    ONLY uses past values — prevents look-ahead bias.
    """
    out = np.zeros_like(series, dtype=float)
    for i in range(len(series)):
        start = max(0, i - 3 * h)
        past  = np.arange(start, i + 1)
        w     = np.exp(-((i - past) ** 2) / (2 * h ** 2))
        out[i] = np.dot(w / w.sum(), series[start : i + 1])
    return out


if __name__ == '__main__':
    econ_df_1 = build_econ_df()
    econ_df_1.to_csv('econ_df_1.csv')
    print("\nSaved to econ_df_1.csv")
