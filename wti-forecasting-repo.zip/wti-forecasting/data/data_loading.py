"""
Data Loading Pipeline — WTI Forecasting
Downloads all required data from FRED and Yahoo Finance.
Run once: python data/data_loading.py
Output:   data/econ_df_1.csv
"""

import pandas as pd
import pandas_datareader.data as web
import yfinance as yf
from datetime import datetime
import time, warnings
warnings.filterwarnings('ignore')

START = datetime(2000, 1, 1)
END   = datetime.now()

FRED_SERIES = {
    'DCOILWTICO':       'WTI',
    'DEXUSEU':          'Dollar/Euro',
    'DJIA':             'DJ',
    'NASDAQCOM':        'NASDAQ',
    'DCOILBRENTEU':     'Brent',
    'CPIENGSL':         'US_CPI_energy',
    'CPIAUCSL':         'US_CPI_total',
    'PPIACO':           'US_PPI_total',
    'FEDFUNDS':         'Fed_Funds_Effective',
    'PIEAEN01EZM661N':  'EU_PPI',
}

YF_SYMBOLS = {
    '^GSPC':    'S&P500',
    'HG=F':     'Copper',
    'GC=F':     'Gold',
    'BTC-USD':  'Bitcoin',
}


def fetch_fred():
    print("Downloading FRED data...")
    df = pd.DataFrame()
    for series_id, name in FRED_SERIES.items():
        for attempt in range(3):
            try:
                s = web.get_data_fred(series_id, START, END)
                s.columns = [name]
                df = s if df.empty else df.join(s, how='outer')
                print(f"  ✅ {name}")
                break
            except Exception as e:
                if attempt == 2:
                    print(f"  ❌ {name}: {e}")
                time.sleep(2)
    return df


def fetch_yfinance():
    print("Downloading Yahoo Finance data...")
    frames = {}
    for ticker, name in YF_SYMBOLS.items():
        try:
            df = yf.download(ticker, start=START, end=END,
                             progress=False)['Close']
            frames[name] = df.rename(name)
            print(f"  ✅ {name}")
        except Exception as e:
            print(f"  ❌ {name}: {e}")
    return pd.concat(frames.values(), axis=1) if frames else pd.DataFrame()


def build_econ_df():
    fred_df = fetch_fred()
    yf_df   = fetch_yfinance()

    # Align indices
    fred_df.index = pd.to_datetime(fred_df.index)
    yf_df.index   = pd.to_datetime(yf_df.index)

    econ_df = fred_df.join(yf_df, how='outer')

    # Complete daily index + forward fill
    full_idx = pd.date_range(start=econ_df.index.min(),
                              end=econ_df.index.max(), freq='D')
    econ_df  = econ_df.reindex(full_idx).ffill().bfill()

    print(f"\n✅ Dataset ready: {econ_df.shape}")
    print(f"   Period: {econ_df.index.min().date()} → {econ_df.index.max().date()}")
    print(f"   Columns: {list(econ_df.columns)}")
    print(f"   NaNs: {econ_df.isna().sum().sum()}")

    econ_df.to_csv('data/econ_df_1.csv')
    print("✅ Saved to data/econ_df_1.csv")
    return econ_df


if __name__ == '__main__':
    econ_df_1 = build_econ_df()
